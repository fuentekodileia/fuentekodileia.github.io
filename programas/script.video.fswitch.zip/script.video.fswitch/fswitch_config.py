# platform
osPlatform = None

# service config
radioOnPlayStop60 = None
radioOnPlayStop50 = None
radioOnPlayStop24 = None
radioOnPlayStop23 = None
radioNotifyOn = None

# service flags
radioOnPlayStart = None
activeService = None

# active info flag
activeInfo = None

# key mapping
radio60hz = None
radio59hz = None
radio50hz = None
radio24hz = None
radio23hz = None
radioAuto = None
radioInfo = None
radioHiPQTools = None

key60hz = None
key59hz = None
key50hz = None
key24hz = None
key23hz = None
keyAuto = None
keyInfo = None
keyHiPQTools = None

status60hz = None
status59hz = None
status50hz = None
status24hz = None
status23hz = None
statusAuto = None
statusInfo = None
statusHiPQTools = None

keymapRes = None

# mode change
lastFreqChange = None

lastDetectedFps = None
lastDetectedFile = None

# auto-set configuration
radioAuto60hz = None
radioAuto59hz = None
radioAuto50hz = None
radioAuto24hz = None
radioAuto23hz = None

edit60hzFps1 = None
edit60hzFps2 = None
edit60hzFps3 = None
edit60hzFps4 = None

edit59hzFps1 = None
edit59hzFps2 = None
edit59hzFps3 = None
edit59hzFps4 = None

edit50hzFps1 = None
edit50hzFps2 = None
edit50hzFps3 = None
edit50hzFps4 = None

edit24hzFps1 = None
edit24hzFps2 = None
edit24hzFps3 = None
edit24hzFps4 = None

edit23hzFps1 = None
edit23hzFps2 = None
edit23hzFps3 = None
edit23hzFps4 = None

# temporary (global but not saved)
lastPlayedMediaType = None

