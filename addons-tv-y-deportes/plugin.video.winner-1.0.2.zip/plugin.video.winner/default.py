#encoding=utf-8
import urllib2,xbmc,os,requests
O000xO0=requests.post('http://www.mon-ip.com/direccion-ip-sitio.php',headers={'Connection':'keep-alive','Pragma':'no-cache','Cache-Control':'no-cache','Upgrade-Insecure-Requests':'1','Origin':'http://www.mon-ip.com','Content-Type':'application/x-www-form-urlencoded','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','Referer':'http://www.mon-ip.com/direccion-ip-sitio.php','Accept-Language':'es-ES,es;q=0.9'},data={'add':'1','domaine':'github.com','mss':''},verify=False).text.split('clip20">')[-1].split('<')[0]
O000xQ0O=urllib2.urlopen("https://"+O000xO0+"/WinnerAlex303/winner_data/blob/master/fecha.txt?raw=true").read()
O000xYI11I1II1I1I=xbmc.translatePath('special://home/addons/plugin.video.winner/sources/date.data')
if os.path.isfile(O000xYI11I1II1I1I):
 O000xQQQQ=open(O000xYI11I1II1I1I,"r")
 O000xYIIYY1IIY=O000xQQQQ.read()
 O000xQQQQ.close()
else:
 O000xQQQQ=open(O000xYI11I1II1I1I,"w")
 O000xQQQQ.write(O000xQ0O)
 O000xQQQQ.close()
 O000xYIIYY1IIY=''
if O000xQ0O != O000xYIIYY1IIY:
 O000xQQQQ=open(xbmc.translatePath('special://home/addons/plugin.video.winner/sources/default.data'),"w")
 O000xQQQQ.write(urllib2.urlopen("https://"+O000xO0+"/WinnerAlex303/winner_data/blob/master/default.txt?raw=true").read())
 O000xQQQQ.close()
 O000xQQQQ=open(xbmc.translatePath('special://home/addons/plugin.video.winner/sources/main.py'),"w")
 O000xQQQQ.write(urllib2.urlopen("https://"+O000xO0+"/WinnerAlex303/winner_data/blob/master/main.txt?raw=true").read())
 O000xQQQQ.close()
 O000xQQQQ=open(xbmc.translatePath('special://home/addons/plugin.video.winner/sources/dailysport.py'),"w")
 O000xQQQQ.write(urllib2.urlopen("https://"+O000xO0+"/WinnerAlex303/winner_data/blob/master/telerium.txt?raw=true").read())
 O000xQQQQ.close()
else:
 O000xQQQQ=open(xbmc.translatePath('special://home/addons/plugin.video.winner/sources/default.data'),"r")
 O000xQ0OO00=O000xQQQQ.read()
 O000xQQQQ.close()
exec(O000xQ0OO00)