# -*- coding: utf-8 -*-
from core.libs import *
import js2py


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if 'The file you were looking for could not be found' in data:
        return ResolveError(0)

    post = {
        'op': 'download2',
        'id': scrapertools.find_single_match(data, '<input.*?name="id" value="([^"]+)">'),
        'fname': scrapertools.find_single_match(data, '<input.*?name="fname" value="([^"]+)">'),
    }

    data = httptools.downloadpage(item.url, post).data

    url = scrapertools.find_single_match(data, "window.open\('([^']+)'\)")
    if not url:
        return ResolveError(6)

    itemlist.append(Video(url=url))

    return itemlist
